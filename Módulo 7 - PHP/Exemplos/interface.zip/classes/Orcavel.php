<?php
interface Orcavel
{
    public function getPreco();
}