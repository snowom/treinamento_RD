<?php
require_once('classes/Conta.php');

class ContaSalario extends Conta {

    //metodo abstrado, pode ser usado somente dentro de uma     classe abstrada e deve ser implementado quando herdamos essa classe abstrata.
    
    // public function retirar($quantia)
    // {
    //     $this->saldo -= $quantia;
    // }
}