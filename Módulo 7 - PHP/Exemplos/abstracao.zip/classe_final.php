<?php
require_once('classes/Conta.php');
require_once('classes/ContaPoupanca.php');

//classe Final, pode ser instanciada, porém não pode ser herdada
class ContaPoupancaUniversitaria extends ContaPoupanca 
{
    
}

